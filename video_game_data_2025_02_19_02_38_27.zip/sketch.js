let table; 
let salesData = {};
let years = [];
let barWidth;
let maxSales = 0;
let hoverBar = null;
let csvurl = "https://raw.githubusercontent.com/Andrew-0909/data-visualization/refs/heads/main/vgsales.csv"

function preload() {
  table = loadTable(csvurl, "csv", "header");
}

function setup() {
  createCanvas(700, 600);
  parseData();
  barWidth = (width - 100)/years.length;
}
function parseData(){
  for(let r = 0; r < table.getRowCount();r++){
    let year = table.getString(r, "Year");
    let sales = float(table.getString(r, "Global_Sales"));
    if(year>=2010 && year<=2016){
      if(salesData[year]){
        salesData[year] += sales
      } else{salesData[year] = sales;
            years.push(year);}
      if(salesData[year]> maxSales){
         maxSales = salesData[year];
         }
    }
  }
  years.sort((a, b) => a-b);
}

function draw() {
  background(220);
  drawBarChart();
  drawAxis();
  drawTitle();
}
function drawBarChart(){
  let margin = 60;
  for(let i = 0; i < years.length; i++){
    let year = years[i];
    let sales = salesData[year];
    let x = margin + i * barWidth
    let barHeight = map(sales, 0, maxSales, 0, height-100);
    let y = height - margin - barHeight;
    if(hoverBar ===i){
       fill(255, 0, 0);
       }else{
         fill(0,0, 255);
       }
    rect(x, y, barWidth - 10, barHeight);
    fill(0)
    textAlign(CENTER, CENTER);
    text(year, x+barWidth/2, height-30);
  }
  if(hoverBar !== null){
     show(hoverBar);
     }
}
 function drawAxis(){
   let margin = 50
   stroke(0)
   strokeWeight(2);
   line(margin, height-margin, width-20, height-margin);
   line(margin, height-margin, margin, 40);
   textAlign(RIGHT);
   textSize(10)
   fill(0)
   
   for(let i = 0; i<=maxSales; i+= 50){
     let y = map(i, 0, maxSales, height-margin, 50);
     text(i, margin-10, y);
     line(margin-5, y, margin+5, y);
   }
   textSize(20);
   textAlign(CENTER, CENTER);
   text("Years", width/2, height-10);
   
   push();
   textSize(16);
   textAlign(CENTER, CENTER);
   translate(10, height/2);
   rotate(-HALF_PI);
   text("Global Sales(Million)", 0,0)
   pop();
 }
function drawTitle(){
  textSize(25);
  textAlign(CENTER, CENTER);
  fill(0)
  text("Video games that selled in 2010-2016", width/2, 30);
}

function show(index){
  let year = years[index];
  let sales = salesData[year];
  fill(50);
  rect(mouseX + 10, mouseY, 100, 30, 5);
  fill(255);
  textAlign(LEFT);
  text(`${year}:${sales.toFixed(1)}M`, mouseX + 15, mouseY +20);
}
function mouseMoved(){
  hoverBar = null;
  let margin = 50;
  for(let i =0; i< years.length; i++){
    let x = margin + i*barWidth;
    if(mouseX> x && mouseX < x+barWidth-10){
       hoverBar = i;
      break;
       }
  }
}