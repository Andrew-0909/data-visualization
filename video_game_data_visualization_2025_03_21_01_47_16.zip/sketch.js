let csvurl = "https://raw.githubusercontent.com/Andrew-0909/data-visualization/refs/heads/main/vgsales.csv";
let table;
let barChart;

class BarChart {
  constructor(x, y, width, height, table) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;

    this.table = table;
    this.salesData = {};
    this.years = [];
    this.barWidth = 0;
    this.maxSales = 0;
    this.hoveredBar = null;

    this.parseData();
  }

  parseData() {
    for (let r = 0; r < this.table.getRowCount(); r++) {
      let year = this.table.getString(r, "Year");
      let sales = float(this.table.getString(r, "Global_Sales"));

      if (year >= 2010 && year <= 2016) {
        if (this.salesData[year]) {
          this.salesData[year] += sales;
        } else {
          this.salesData[year] = sales;
          this.years.push(year);
        }
        if (this.salesData[year] > this.maxSales) {
          this.maxSales = this.salesData[year];
        }
      }
    }
    this.years.sort((a, b) => a - b);
    this.barWidth = (this.width - 100) / this.years.length;
  }

  drawBarChart() {
    background(220);
    let margin = 60;
    for (let i = 0; i < this.years.length; i++) {
      let year = this.years[i];
      let sales = this.salesData[year];
      let x = margin + i * this.barWidth;
      let barHeight = map(sales, 0, this.maxSales, 0, this.height - 100);
      let y = this.height - margin - barHeight;

      if (this.hoveredBar === i) { // Fixed hover logic
        fill(255, 0, 0);
      } else {
        fill(0, 0, 255);
      }

      rect(x, y, this.barWidth - 10, barHeight);
      fill(0);
      textAlign(CENTER, CENTER);
      text(year, x + this.barWidth / 2, this.height - 30);
    }
    
    if (this.hoveredBar !== null) {
      this.show(this.hoveredBar);
    }

    this.drawAxis();
    this.drawTitle();
  }

  drawAxis() {
    let margin = 50;
    stroke(0);
    strokeWeight(2);

    line(margin, this.height - margin, this.width - 20, this.height - margin);
    line(margin, this.height - margin, margin, 40);

    textAlign(RIGHT);
    textSize(10);
    fill(0);

    for (let i = 0; i <= this.maxSales; i += 50) {
      let y = map(i, 0, this.maxSales, this.height - margin, 50);
      text(i, margin - 10, y); // Fixed
      line(margin - 5, y, margin + 5, y);
    }

    textSize(20);
    textAlign(CENTER, CENTER);
    text("Years", this.width / 2, this.height - 10);

    push();
    textSize(16);
    textAlign(CENTER, CENTER);
    translate(10, this.height / 2);
    rotate(-HALF_PI);
    text("Global Sales (Million)", 0, 0);
    pop();
  }

  drawTitle() {
    textSize(25);
    textAlign(CENTER, CENTER);
    fill(0);
    text("Video games that selled in 2010-2016", this.width / 2, 30);
  }

  updateHover(mx, my) {
    this.hoveredBar = null;
    let margin = 50;
    for (let i = 0; i < this.years.length; i++) {
      let x = margin + i * this.barWidth;
      if (mx > x && mx < x + this.barWidth - 10) {
        this.hoveredBar = i;
        break;
      }
    }
  }

  show(index) {
    let year = this.years[index];
    if (year in this.salesData) {
    let sales = this.salesData[year];

      fill(50);
      rect(mouseX + 10, mouseY, 100, 30, 5);
      fill(255);
      textAlign(LEFT);
      text(`${year}: ${sales.toFixed(1)}M`, mouseX + 15, mouseY + 20);
    }
  }
}

function preload() {
  table = loadTable(csvurl, "csv", "header");
}

function setup() {
  createCanvas(700, 600);
  barChart = new BarChart(0, 0, width, height, table);
}

function draw() {
  barChart.drawBarChart();
}

function mouseMoved() {
  barChart.updateHover(mouseX, mouseY);
}
